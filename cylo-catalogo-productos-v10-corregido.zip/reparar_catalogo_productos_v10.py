# -*- coding: utf-8 -*-
"""
CYLO REPAIR V10 - Ejecutar en la raíz del proyecto.
Corrige categorías bloqueadas y enlaces /index.htmlproductos/ rotos.
"""
from pathlib import Path
import re
ROOT=Path(__file__).resolve().parent
CATS=[("Desechables","cat-desechables"),("Utensilios","cat-utensilios"),("Cocción","cat-cocci-n"),("Accesorios","cat-accesorios"),("Repostería","cat-reposter-a"),("Pizzería","cat-pizzer-a"),("Contenedores","cat-contenedores"),("Catering","cat-catering"),("Servicio","cat-servicio"),("Bartender","cat-bartender"),("Cafetería","cat-cafeter-a"),("Presentación","cat-presentaci-n"),("Vajilla","cat-vajilla"),("Cristalería","cat-cristaler-a")]
CATEGORY_LIST='<ul class="category-list">\n  <li><a href="/Catalogo-digital-2026.html">Catálogo completo</a></li>\n' + "\n".join(f'  <li><a href="/Catalogo-digital-2026.html?cat={cid}#{cid}">{name}</a></li>' for name,cid in CATS) + '\n</ul>'
def fix(text):
    text=re.sub(r'<ul class="category-list">.*?</ul>', CATEGORY_LIST, text, count=1, flags=re.S)
    for name,cid in CATS:
        text=re.sub(r'href="(?:https://www\.cyloguatemala\.me)?/?(?:\.\./|\./)?Catalogo-digital-2026(?:\.html)?(?:\?[^"#]*)?#'+re.escape(cid)+r'"', f'href="/Catalogo-digital-2026.html?cat={cid}#{cid}"', text)
        text=re.sub(r'href="#'+re.escape(cid)+r'"', f'href="/Catalogo-digital-2026.html?cat={cid}#{cid}"', text)
        text=text.replace(f'value="#{cid}"', f'value="{cid}"')
    text=text.replace('href="../index.htmlproductos/','href="/productos/')
    text=text.replace('href="./index.htmlproductos/','href="/productos/')
    text=text.replace('href="/index.htmlproductos/','href="/productos/')
    text=text.replace('href="index.htmlproductos/','href="/productos/')
    text=text.replace('/index.htmlproductos/','/productos/')
    text=re.sub(r'href="\.\./productos/([^"]+)"', r'href="/productos/\1"', text)
    text=re.sub(r'href="\./productos/([^"]+)"', r'href="/productos/\1"', text)
    return text
changed=0
for p in list(ROOT.glob('*.html'))+list((ROOT/'productos').rglob('*.html') if (ROOT/'productos').exists() else [])+list((ROOT/'productos_generados').rglob('*.html') if (ROOT/'productos_generados').exists() else []):
    old=p.read_text(encoding='utf-8',errors='replace')
    new=fix(old)
    if new!=old:
        p.write_text(new,encoding='utf-8')
        changed+=1
        print('Corregido:',p.relative_to(ROOT))
print('Archivos corregidos:',changed)
