# -*- coding: utf-8 -*-
"""
Generador masivo de páginas de producto CYLO Guatemala
------------------------------------------------------
Archivos esperados en la misma carpeta:
- generador.py
- template.html
- productos_cylo.xlsx

Salida:
- productos_generados/*.html
- productos_generados/sitemap_productos.xml
- productos_generados/reporte_generacion.csv
"""

import json
import re
import unicodedata
from datetime import datetime
from pathlib import Path
from urllib.parse import quote

import pandas as pd


# =========================
# CONFIGURACIÓN
# =========================

BASE_DIR = Path(__file__).resolve().parent

ARCHIVO_EXCEL = BASE_DIR / "productos_cylo.xlsx"
ARCHIVO_TEMPLATE = BASE_DIR / "template.html"
CARPETA_SALIDA = BASE_DIR / "productos_generados"

DOMINIO_PRODUCTOS = "https://www.cyloguatemala.me/productos/"
URL_CATALOGO = "https://www.cyloguatemala.me/Catalogo-digital-2026.html"
WHATSAPP = "50248005692"

CARPETA_SALIDA.mkdir(exist_ok=True)


# =========================
# FUNCIONES BASE
# =========================

def salir_error(mensaje):
    print("\nERROR:")
    print(mensaje)
    raise SystemExit(1)


def normalizar_texto(texto):
    texto = "" if texto is None else str(texto)
    texto = unicodedata.normalize("NFKD", texto)
    texto = texto.encode("ascii", "ignore").decode("ascii")
    return texto


def normalizar_columna(columna):
    columna = normalizar_texto(columna).lower().strip()
    columna = re.sub(r"[^a-z0-9]+", "_", columna)
    columna = columna.strip("_")
    return columna


def limpiar_slug(texto):
    texto = normalizar_texto(texto).lower().strip()
    texto = texto.replace(".html", "")
    texto = re.sub(r"[^a-z0-9\s-]", "", texto)
    texto = re.sub(r"[\s_]+", "-", texto)
    texto = re.sub(r"-+", "-", texto)
    texto = texto.strip("-")
    return texto or "producto"


def limpiar_html_texto(texto):
    texto = "" if texto is None else str(texto)
    texto = texto.replace("&", "&amp;")
    texto = texto.replace("<", "&lt;")
    texto = texto.replace(">", "&gt;")
    texto = texto.replace('"', "&quot;")
    return texto.strip()


def texto_plano(texto):
    texto = "" if texto is None else str(texto)
    texto = re.sub(r"\s+", " ", texto).strip()
    return texto


def meta_155(texto):
    texto = texto_plano(texto)
    if len(texto) <= 155:
        return texto
    return texto[:152].rstrip() + "..."


def precio_formateado(valor):
    try:
        if str(valor).strip() == "":
            return "0.00"
        return f"{float(valor):.2f}"
    except Exception:
        return "0.00"


def unidad_formateada(valor):
    try:
        if str(valor).strip() == "":
            return ""
        numero = float(valor)
        if numero.is_integer():
            return str(int(numero))
        return str(numero)
    except Exception:
        return str(valor).strip()


def obtener(row, mapa_columnas, *nombres, default=""):
    for nombre in nombres:
        clave = normalizar_columna(nombre)
        if clave in mapa_columnas:
            valor = row.get(mapa_columnas[clave], "")
            if pd.notna(valor) and str(valor).strip() != "":
                return str(valor).strip()
    return default


def reemplazar_variables(html, variables):
    for clave, valor in variables.items():
        html = html.replace("{{" + clave + "}}", str(valor))
    return html


# =========================
# CONTENIDO SEO
# =========================

def generar_keyword(nombre, categoria):
    categoria_txt = "" if categoria.upper() in ["N/A", "NA", "SIN CATEGORIA"] else categoria
    base = f"{nombre} {categoria_txt} Guatemala"
    return texto_plano(base).lower()


def generar_titulo_seo(nombre, categoria):
    titulo = f"{nombre} al por mayor en Guatemala | CYLO"
    if len(titulo) > 62:
        titulo = f"{nombre} | Precio al por mayor | CYLO"
    return texto_plano(titulo)


def generar_meta(nombre, unidades, categoria):
    partes = [
        f"Compra {nombre} en Guatemala",
        "precio al por mayor",
    ]
    if unidades:
        partes.append(f"presentación de {unidades} unidades")
    if categoria:
        partes.append(f"categoría {categoria}")
    partes.append("cotiza por WhatsApp con CYLO")
    return meta_155(". ".join(partes) + ".")


def generar_descripcion_larga(nombre, categoria, unidades, descripcion_excel):
    if descripcion_excel and len(descripcion_excel.strip()) >= 120:
        base = descripcion_excel.strip()
    else:
        base = (
            f"El producto {nombre} forma parte del catálogo institucional de CYLO Guatemala, "
            f"orientado a negocios que necesitan abastecimiento constante, precios competitivos "
            f"y disponibilidad para compras al por mayor."
        )

    presentacion = ""
    if unidades:
        presentacion = (
            f" Su presentación de {unidades} unidades facilita la planificación de compras, "
            f"el control de inventario y la reposición operativa."
        )

    categoria_txt = f" dentro de la categoría {categoria}" if categoria else ""

    extra = (
        f" Este producto es una alternativa práctica para restaurantes, cafeterías, hoteles, "
        f"servicios de alimentación, distribuidores y empresas que requieren insumos confiables{categoria_txt}. "
        f"CYLO Guatemala atiende pedidos para clientes institucionales y comerciales, con cobertura en Ciudad de Guatemala "
        f"y distintos departamentos del país."
        f"{presentacion} Para compras por volumen, se recomienda solicitar cotización directa por WhatsApp "
        f"y confirmar disponibilidad antes de programar el despacho."
    )

    return texto_plano(base + extra)


def generar_usos(nombre, categoria):
    categoria_txt = categoria if categoria else "operaciones de alimentos"
    return [
        f"Uso en restaurantes, cafeterías y negocios de comida que requieren {nombre.lower()}.",
        f"Abastecimiento para compras institucionales dentro de la categoría {categoria_txt}.",
        "Reposición de inventario para operaciones comerciales con consumo recurrente."
    ]


def generar_beneficios(nombre):
    return [
        "Disponible para cotización al por mayor en Guatemala.",
        "Apoya la planificación de inventario y compras recurrentes.",
        "Atención comercial directa por WhatsApp para confirmar precio, stock y despacho."
    ]


def generar_faq(nombre):
    return [
        {
            "q": f"¿Dónde puedo comprar {nombre} en Guatemala?",
            "a": f"Puedes cotizar {nombre} directamente con CYLO Guatemala por WhatsApp. Atendemos compras al por mayor para negocios, distribuidores y clientes institucionales."
        },
        {
            "q": "¿El producto se vende por unidad o por caja?",
            "a": "La presentación depende del producto registrado en el catálogo. En cada ficha se muestra la cantidad de unidades incluida para facilitar la cotización."
        },
        {
            "q": "¿Hacen envíos a departamentos?",
            "a": "Sí. CYLO Guatemala puede coordinar entregas en Ciudad de Guatemala y distintos departamentos, sujeto a disponibilidad, volumen de compra y cobertura logística."
        }
    ]


# =========================
# BLOQUES INYECTABLES
# =========================

CSS_SEO = """
/* Bloques SEO generados automáticamente */
.product-extra-seo {
  margin: 40px auto 70px auto;
  color: #1B2A4A;
}
.product-extra-seo h2 {
  font-size: 1.55rem;
  margin: 28px 0 12px 0;
  color: #1B2A4A;
}
.product-extra-seo h3 {
  font-size: 1.05rem;
  margin: 20px 0 8px 0;
  color: #1B2A4A;
}
.product-extra-seo p,
.product-extra-seo li {
  font-size: 0.98rem;
  line-height: 1.75;
  color: #4A5568;
}
.product-extra-seo ul {
  padding-left: 22px;
}
.product-extra-seo .seo-card {
  background: #F4F6F9;
  border: 1px solid #D8E2EF;
  border-radius: 12px;
  padding: 22px;
  margin-top: 18px;
}
.related-grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 16px;
  margin-top: 18px;
}
.related-grid a {
  display: block;
  background: #FFFFFF;
  border: 1px solid #D8E2EF;
  border-radius: 10px;
  padding: 16px;
  color: #1B2A4A;
  font-weight: 700;
  text-decoration: none;
}
.related-grid a:hover {
  border-color: #F47B20;
  color: #F47B20;
}
@media (max-width: 900px) {
  .related-grid {
    grid-template-columns: 1fr;
  }
}
"""


def inyectar_css_si_falta(html):
    if ".product-extra-seo" in html:
        return html

    if "</style>" in html:
        return html.replace("</style>", CSS_SEO + "\n</style>", 1)

    if "</head>" in html:
        bloque = f"<style>{CSS_SEO}</style>\n"
        return html.replace("</head>", bloque + "</head>", 1)

    return html


def construir_bloque_seo(producto, relacionados):
    faq = generar_faq(producto["nombre"])

    relacionados_html = ""
    for rel in relacionados:
        relacionados_html += (
            f'<a href="{DOMINIO_PRODUCTOS}{rel["slug"]}.html">'
            f'{limpiar_html_texto(rel["nombre"])}</a>\n'
        )

    usos_html = "\n".join(f"<li>{limpiar_html_texto(u)}</li>" for u in producto["usos"])
    beneficios_html = "\n".join(f"<li>{limpiar_html_texto(b)}</li>" for b in producto["beneficios"])

    faq_html = ""
    for item in faq:
        faq_html += f"""
        <h3>{limpiar_html_texto(item["q"])}</h3>
        <p>{limpiar_html_texto(item["a"])}</p>
        """

    return f"""
<section class="product-extra-seo">
  <div class="seo-card">
    <h2>Descripción del producto</h2>
    <p>{limpiar_html_texto(producto["descripcion_larga"])}</p>
  </div>

  <h2>Aplicaciones de {limpiar_html_texto(producto["nombre"])}</h2>
  <ul>
    {usos_html}
  </ul>

  <h2>Beneficios para compras al por mayor</h2>
  <ul>
    {beneficios_html}
  </ul>

  <h2>Preguntas frecuentes</h2>
  {faq_html}

  <h2>Productos relacionados</h2>
  <div class="related-grid">
    {relacionados_html}
  </div>
</section>
"""


def inyectar_bloque_seo_si_falta(html, producto, relacionados):
    if "product-extra-seo" in html or "product-description" in html or "product-faq" in html:
        return html

    bloque = construir_bloque_seo(producto, relacionados)

    if re.search(r"</main>", html, flags=re.IGNORECASE):
        return re.sub(r"</main>", bloque + "\n</main>", html, count=1, flags=re.IGNORECASE)

    if re.search(r"</body>", html, flags=re.IGNORECASE):
        return re.sub(r"</body>", bloque + "\n</body>", html, count=1, flags=re.IGNORECASE)

    return html + bloque


def generar_faq_schema(nombre):
    faq_items = generar_faq(nombre)
    schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {
                "@type": "Question",
                "name": item["q"],
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": item["a"]
                }
            }
            for item in faq_items
        ]
    }

    return (
        '<script type="application/ld+json">\n'
        + json.dumps(schema, ensure_ascii=False, indent=2)
        + "\n</script>\n"
    )


def generar_breadcrumb_schema(producto):
    schema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": [
            {
                "@type": "ListItem",
                "position": 1,
                "name": "Inicio",
                "item": "https://www.cyloguatemala.me/"
            },
            {
                "@type": "ListItem",
                "position": 2,
                "name": "Catálogo",
                "item": URL_CATALOGO
            },
            {
                "@type": "ListItem",
                "position": 3,
                "name": producto["categoria"] or "Producto",
                "item": URL_CATALOGO
            },
            {
                "@type": "ListItem",
                "position": 4,
                "name": producto["nombre"],
                "item": f'{DOMINIO_PRODUCTOS}{producto["slug"]}.html'
            }
        ]
    }

    return (
        '<script type="application/ld+json">\n'
        + json.dumps(schema, ensure_ascii=False, indent=2)
        + "\n</script>\n"
    )


def inyectar_schema_extra(html, producto):
    bloques = ""

    if '"@type": "FAQPage"' not in html:
        bloques += generar_faq_schema(producto["nombre"])

    if '"@type": "BreadcrumbList"' not in html:
        bloques += generar_breadcrumb_schema(producto)

    if bloques and "</head>" in html:
        return html.replace("</head>", bloques + "</head>", 1)

    return html


# =========================
# VALIDACIONES INICIALES
# =========================

if not ARCHIVO_EXCEL.exists():
    salir_error(f"No encontré el Excel: {ARCHIVO_EXCEL}")

if not ARCHIVO_TEMPLATE.exists():
    salir_error(f"No encontré el template: {ARCHIVO_TEMPLATE}")

plantilla = ARCHIVO_TEMPLATE.read_text(encoding="utf-8")

plantilla_inicio = plantilla.lstrip().lower()

if plantilla_inicio.startswith("import ") or plantilla_inicio.startswith("from "):
    salir_error(
        "Tu template.html contiene código Python. "
        "El archivo template.html debe contener SOLO HTML. "
        "Este código debe ir únicamente en generador.py."
    )

if "<html" not in plantilla.lower() or "</html>" not in plantilla.lower():
    salir_error(
        "Tu template.html no parece ser un HTML completo. "
        "Debe iniciar con <!DOCTYPE html> y tener <html>, <head> y <body>."
    )


print("Cargando Excel...")
df = pd.read_excel(ARCHIVO_EXCEL).fillna("")
mapa_columnas = {normalizar_columna(col): col for col in df.columns}

print(f"Columnas detectadas: {list(df.columns)}")
print(f"Productos detectados: {len(df)}")


# =========================
# PREPARAR PRODUCTOS
# =========================

productos = []
slugs_usados = {}

for index, row in df.iterrows():
    nombre = obtener(row, mapa_columnas, "Nombre_Producto", "Nombre Producto", "Producto", "Nombre", default="")
    if not nombre:
        print(f"Fila {index + 2}: omitida porque no tiene nombre de producto.")
        continue

    categoria = obtener(row, mapa_columnas, "Categoria", "Categoría", "Linea", "Línea", default="")
    descripcion_excel = obtener(row, mapa_columnas, "Descripcion_Producto", "Descripción Producto", "Descripcion", "Descripción", default="")
    url_imagen = obtener(row, mapa_columnas, "URL_Imagen", "URL Imagen", "Imagen", default="")
    sku = obtener(row, mapa_columnas, "SKU", "Codigo", "Código", default="")
    precio = precio_formateado(obtener(row, mapa_columnas, "Precio_Web", "Precio Web", "Precio", default="0"))
    unidades = unidad_formateada(obtener(row, mapa_columnas, "Unidades", "Presentacion", "Presentación", default=""))

    slug_base_excel = obtener(row, mapa_columnas, "URL_Amigable", "URL Amigable", "Slug", "URL", default="")
    slug_base = limpiar_slug(slug_base_excel or nombre)

    contador = slugs_usados.get(slug_base, 0)

    if contador == 0:
        slug = slug_base
    else:
        slug = f"{slug_base}-{contador + 1}"

    slugs_usados[slug_base] = contador + 1

    titulo_excel = obtener(row, mapa_columnas, "Titulo_SEO", "Título SEO", "Titulo SEO", default="")
    meta_excel = obtener(row, mapa_columnas, "Meta_Descripcion", "Meta Descripcion", "Meta Descripción", default="")

    descripcion_larga = generar_descripcion_larga(nombre, categoria, unidades, descripcion_excel)
    keyword = generar_keyword(nombre, categoria)

    producto = {
        "index": index,
        "nombre": texto_plano(nombre),
        "categoria": texto_plano(categoria),
        "descripcion_excel": texto_plano(descripcion_excel),
        "descripcion_larga": descripcion_larga,
        "url_imagen": texto_plano(url_imagen),
        "sku": texto_plano(sku),
        "precio": precio,
        "unidades": unidades,
        "slug": slug,
        "titulo_seo": texto_plano(titulo_excel) if titulo_excel else generar_titulo_seo(nombre, categoria),
        "meta_descripcion": meta_155(meta_excel) if meta_excel else generar_meta(nombre, unidades, categoria),
        "keyword_principal": keyword,
        "usos": generar_usos(nombre, categoria),
        "beneficios": generar_beneficios(nombre),
    }

    productos.append(producto)


if not productos:
    salir_error("No se pudo generar ningún producto. Revisa la columna Nombre_Producto del Excel.")


# =========================
# RELACIONADOS
# =========================

def relacionados_para(producto_actual, cantidad=3):
    misma_categoria = [
        p for p in productos
        if p["slug"] != producto_actual["slug"] and p["categoria"] == producto_actual["categoria"]
    ]

    otros = [
        p for p in productos
        if p["slug"] != producto_actual["slug"] and p["categoria"] != producto_actual["categoria"]
    ]

    seleccion = (misma_categoria + otros)[:cantidad]

    while len(seleccion) < cantidad:
        seleccion.append(producto_actual)

    return seleccion


# =========================
# GENERACIÓN HTML
# =========================

urls_sitemap = []
reporte = []

print("\nGenerando páginas HTML...")

for i, producto in enumerate(productos, start=1):
    relacionados = relacionados_para(producto, 3)

    mensaje_whatsapp = quote(
        f"Hola CYLO, quiero cotizar {producto['nombre']} SKU {producto['sku']}",
        safe=""
    )

    variables = {
        "titulo_seo": limpiar_html_texto(producto["titulo_seo"]),
        "meta_descripcion": limpiar_html_texto(producto["meta_descripcion"]),
        "nombre_producto": limpiar_html_texto(producto["nombre"]),
        "categoria": limpiar_html_texto(producto["categoria"]),
        "url_imagen": limpiar_html_texto(producto["url_imagen"]),
        "precio": producto["precio"],
        "unidades": limpiar_html_texto(producto["unidades"]),
        "sku": limpiar_html_texto(producto["sku"]),
        "url_amigable": producto["slug"],

        "producto": limpiar_html_texto(producto["nombre"]),
        "capacidad": "",
        "unidad": "",
        "keyword_principal": limpiar_html_texto(producto["keyword_principal"]),
        "descripcion_larga": limpiar_html_texto(producto["descripcion_larga"]),
        "aplicacion": "Foodservice, restaurantes, hoteles, cafeterías y compras institucionales",
        "uso_1": limpiar_html_texto(producto["usos"][0]),
        "uso_2": limpiar_html_texto(producto["usos"][1]),
        "uso_3": limpiar_html_texto(producto["usos"][2]),
        "beneficio_1": limpiar_html_texto(producto["beneficios"][0]),
        "beneficio_2": limpiar_html_texto(producto["beneficios"][1]),
        "beneficio_3": limpiar_html_texto(producto["beneficios"][2]),
        "whatsapp_url": f"https://wa.me/{WHATSAPP}?text={mensaje_whatsapp}",
        "whatsapp_mensaje": mensaje_whatsapp,

        "relacionado_1": relacionados[0]["slug"],
        "producto_rel_1": limpiar_html_texto(relacionados[0]["nombre"]),
        "relacionado_1_imagen": limpiar_html_texto(relacionados[0].get("url_imagen", "")),
        "relacionado_1_precio": relacionados[0].get("precio", "0.00"),
        "relacionado_1_unidades": limpiar_html_texto(relacionados[0].get("unidades", "")),

        "relacionado_2": relacionados[1]["slug"],
        "producto_rel_2": limpiar_html_texto(relacionados[1]["nombre"]),
        "relacionado_2_imagen": limpiar_html_texto(relacionados[1].get("url_imagen", "")),
        "relacionado_2_precio": relacionados[1].get("precio", "0.00"),
        "relacionado_2_unidades": limpiar_html_texto(relacionados[1].get("unidades", "")),

        "relacionado_3": relacionados[2]["slug"],
        "producto_rel_3": limpiar_html_texto(relacionados[2]["nombre"]),
        "relacionado_3_imagen": limpiar_html_texto(relacionados[2].get("url_imagen", "")),
        "relacionado_3_precio": relacionados[2].get("precio", "0.00"),
        "relacionado_3_unidades": limpiar_html_texto(relacionados[2].get("unidades", "")),
    }

    html_final = plantilla
    html_final = inyectar_css_si_falta(html_final)
    html_final = reemplazar_variables(html_final, variables)
    html_final = inyectar_bloque_seo_si_falta(html_final, producto, relacionados)
    html_final = inyectar_schema_extra(html_final, producto)

    pendientes = sorted(set(re.findall(r"\{\{[^{}]+\}\}", html_final)))

    for pendiente in pendientes:
        html_final = html_final.replace(pendiente, "")

    ruta_html = CARPETA_SALIDA / f"{producto['slug']}.html"
    ruta_html.write_text(html_final, encoding="utf-8")

    url_publica = f"{DOMINIO_PRODUCTOS}{producto['slug']}.html"
    urls_sitemap.append(url_publica)

    reporte.append({
        "producto": producto["nombre"],
        "sku": producto["sku"],
        "categoria": producto["categoria"],
        "archivo": ruta_html.name,
        "url": url_publica,
        "variables_pendientes_eliminadas": ", ".join(pendientes)
    })

    if i % 50 == 0 or i == len(productos):
        print(f"  {i}/{len(productos)} productos generados...")


# =========================
# SITEMAP
# =========================

print("\nGenerando sitemap...")

fecha_hoy = datetime.today().strftime("%Y-%m-%d")

sitemap = '<?xml version="1.0" encoding="UTF-8"?>\n'
sitemap += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'

for url in urls_sitemap:
    sitemap += "  <url>\n"
    sitemap += f"    <loc>{url}</loc>\n"
    sitemap += f"    <lastmod>{fecha_hoy}</lastmod>\n"
    sitemap += "    <changefreq>monthly</changefreq>\n"
    sitemap += "    <priority>0.8</priority>\n"
    sitemap += "  </url>\n"

sitemap += "</urlset>\n"

(CARPETA_SALIDA / "sitemap_productos.xml").write_text(sitemap, encoding="utf-8")


# =========================
# REPORTE
# =========================

pd.DataFrame(reporte).to_csv(CARPETA_SALIDA / "reporte_generacion.csv", index=False, encoding="utf-8-sig")


print("\nLISTO.")
print(f"Productos generados: {len(productos)}")
print(f"Carpeta de salida: {CARPETA_SALIDA}")
print(f"Sitemap: {CARPETA_SALIDA / 'sitemap_productos.xml'}")
print(f"Reporte: {CARPETA_SALIDA / 'reporte_generacion.csv'}")
print("\nAbre un archivo dentro de productos_generados para revisar el resultado.")